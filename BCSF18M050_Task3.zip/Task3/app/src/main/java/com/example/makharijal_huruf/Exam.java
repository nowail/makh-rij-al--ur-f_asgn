package com.example.makharijal_huruf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.concurrent.ThreadLocalRandom;


public class Exam extends AppCompatActivity {

    private question [] ques; private question [] quiz;
    private ScrollView sV;
    private TableLayout tbL; private Button sub;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam);
        start();
        create_Quiz();
        load_Quiz();
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int  correctCount = 0;
                for (int i =0; i<5;i++){
                    RadioGroup rg = findViewById(i+4000);
                    RadioButton rb = findViewById(rg.getCheckedRadioButtonId());
                    Log.d("STATE",quiz[i].correct_op);
                    Log.d("STATE",rb.getText().toString());

                    if (quiz[i].correct_op.equals(rb.getText().toString())) {
                        correctCount++;
                        Log.d("STATE", "rb.getText().toString()");
                    }

                }
                tbL.removeAllViews();
                result(correctCount);
            }
        });
    }

    private void start(){
        sV = findViewById(R.id.scrollid);
        tbL = findViewById(R.id.tablelayoutExam);

        ques = new question[]{
                new question("The letters خ غ are from","Halqiyah",new options[]
                        {
                                new options("Lahatiyah"),
                                new options("Tarfiyah"),
                                new options("Halqiyah"),
                                new options("Ghunna"),
                        }),
                new question("Shajariyah-Haafiyah  letters are ","ی ض",new options[]
                        {
                                new options("ی ض"),
                                new options("ل"),
                                new options("ن"),
                                new options("ر"),
                        }),
                new question("The letter ت د ط are from\n","Nit-eeyah",new options[]
                        {
                                new options("Nit-eeyah"),
                                new options("Tarfiyah"),
                                new options("Halqiyah"),
                                new options("Ghunna"),
                        }),
                new question("The letter ذ is from\n","Lisaveyah3",new options[]
                        {
                                new options("Lisaveyah"),
                                new options("Tarfiyah"),
                                new options("Halqiyah"),
                                new options("Ghunna"),
                        }),

                new question("The letters م are from ","Ghunna",new options[]
                        {
                                new options("Lahatiyah"),
                                new options("Tarfiyah"),
                                new options("Halqiyah"),
                                new options("Ghunna"),
                        }),
                new question("The letters باَ بوُ بىِ  are from ","Ghunna",new options[]
                        {
                                new options("Lahatiyah"),
                                new options("Tarfiyah"),
                                new options("Niteeyah"),
                                new options("Ghunna"),
                        }),
                new question("The letters م is from makharij","Ghunna",new options[]
                        {
                                new options("Lahatiyah"),
                                new options("Tarfiyah"),
                                new options("Halqiyah"),
                                new options("Ghunna"),
                        }),
                new question("The letters د is belong from which makharij","Niteeyah",new options[]
                        {
                                new options("Lahatiyah"),
                                new options("Tarfiyah"),
                                new options("Niteeyah"),
                                new options("Ghunna"),
                        }),

        };
    }
    private void create_Quiz(){
        quiz = new question[5];
        for(int i=0;i<5;i++) {
            int randomNum = ThreadLocalRandom.current().nextInt(0, 12 + 1);
            quiz[i] = ques[randomNum];
        }
    }
    private void result(int count){
        TableRow tbRow = new TableRow(this);
        TextView tv0 = new TextView(this);
        tv0.setText("Wrong : " + String.valueOf(5-count));
        tv0.setTextSize(25);

        tbRow.addView(tv0);
        tbL.addView(tbRow);
        tbRow = new TableRow(this);
        tv0 = new TextView(this);
        tv0.setText("Correct : " + String.valueOf(count));
        tv0.setTextSize(25);
        tbRow.addView(tv0);
        tbL.addView(tbRow);
    }

    private void RadioButton(TableLayout tb, @NonNull options[] options , int id) {
        RadioButton[] rb = new RadioButton[options.length];
        RadioGroup rg = new RadioGroup(this);
        rg.setId(id+4000);
        TableRow tbRow = new TableRow(this);

        for(int i=0; i<options.length; i++){
            rb[i]  = new RadioButton(this);
            rb[i].setText(options[i].value);
            rb[i].setId(id+i*100 + 100);
            rg.addView(rb[i]);
            if (i==1) {
                tbRow.addView(rg);
                tb.addView(tbRow);
                tbRow = new TableRow(this);
            }

        }
        tb.addView(tbRow);

    }
    @SuppressLint("ResourceType")
    private void load_Quiz(){
        TextView tv;
        Button bt;
        TableRow tbRow;
        for(int i=0;i<5;i++) {
            tbRow = new TableRow(this);


            TextView tv0 = new TextView(this);
            int num = i+1;
            tv0.setText("Q # "+num);
            tv0.setTextSize(17);
            tv0.setTypeface(null, Typeface.BOLD);

            tbRow.addView(tv0);
            tbL.addView(tbRow);
            tbRow = new TableRow(this);


            TextView tv2 = new TextView(this);
            tv2.setText(quiz[i].statement);
            tv2.setTypeface(null, Typeface.BOLD);
            tv2.setTextSize(17);
            tbRow.addView(tv2);
            tbL.addView(tbRow);

            tbRow = new TableRow(this);
            RadioButton(tbL ,quiz[i].op ,i );


            tbL.addView(tbRow);

        }

        sub = new Button(this);
        sub.setText("Finish");
//        submit.setId(101);
        tbRow = new TableRow(this);
        tbRow.addView(sub);
        tbL.addView(tbRow);

    }





    class options{
        public String value;

        options ()
        {
        }
        options(String val)
        {
            this.value=val;
        }


    }
    class question {
        String statement , correct_op;
        Boolean correct;
        options[] op;

        question(String st, String correct, Exam.options[] o)
        {
            this.statement=st;
            this.correct_op=correct;
            this.op=o;
        }
    }
}